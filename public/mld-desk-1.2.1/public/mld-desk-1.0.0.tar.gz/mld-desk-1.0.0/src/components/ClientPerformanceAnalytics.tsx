import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  
  ResponsiveContainer,
  Legend,
} from "recharts";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";

const weeklyData = [
  { period: "Week 1", requested: 45, delivered: 42, failed: 3 },
  { period: "Week 2", requested: 52, delivered: 48, failed: 4 },
  { period: "Week 3", requested: 48, delivered: 46, failed: 2 },
  { period: "Week 4", requested: 61, delivered: 58, failed: 3 },
];

const monthlyData = [
  { period: "Jan", requested: 156, delivered: 148, failed: 8 },
  { period: "Feb", requested: 178, delivered: 165, failed: 13 },
  { period: "Mar", requested: 203, delivered: 194, failed: 9 },
  { period: "Apr", requested: 189, delivered: 182, failed: 7 },
  { period: "May", requested: 215, delivered: 208, failed: 7 },
  { period: "Jun", requested: 234, delivered: 228, failed: 6 },
];

const chartConfig = {
  requested: {
    label: "Requested",
    color: "green",
  },
  delivered: {
    label: "Delivered",
    color: "hsl(var(--success))",
  },
  failed: {
    label: "Failed",
    color: "hsl(var(--destructive))",
  },
};

export function ClientPerformanceAnalytics() {
  const [period, setPeriod] = useState<"weekly" | "monthly">("weekly");
  const data = period === "weekly" ? weeklyData : monthlyData;

  const totalRequested = data.reduce((sum, item) => sum + item.requested, 0);
  const totalDelivered = data.reduce((sum, item) => sum + item.delivered, 0);
  const successRate = ((totalDelivered / totalRequested) * 100).toFixed(1);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Performance Analytics</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground">Orders Requested</p>
            <p className="text-2xl font-bold text-foreground mt-1">
              {totalRequested}
            </p>
          </div>
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground">Delivered</p>
            <p className="text-2xl font-bold text-success mt-1">
              {totalDelivered}
            </p>
          </div>
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground">Success Rate</p>
            <p className="text-2xl font-bold text-primary mt-1">
              {successRate}%
            </p>
          </div>
        </div>

        <Tabs
          value={period}
          onValueChange={(v) => setPeriod(v as "weekly" | "monthly")}
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="weekly">Weekly Report</TabsTrigger>
            <TabsTrigger value="monthly">Monthly Report</TabsTrigger>
          </TabsList>

          <TabsContent value="weekly" className="space-y-4">
            <ChartContainer config={chartConfig} className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke=""
                  />
                  <XAxis
                    dataKey="period"
                    stroke="hsl(var(--muted-foreground))"
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Bar
                    dataKey="requested"
                    fill="orange"
                    name="Requested"
                  />
                  <Bar
                    dataKey="delivered"
                    fill="green"
                    name="Delivered"
                  />
                  <Bar
                    dataKey="failed"
                    fill="red"
                    name="Failed"
                  />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </TabsContent>

          <TabsContent value="monthly" className="space-y-4">
            <ChartContainer config={chartConfig} className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyData}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="hsl(var(--border))"
                  />
                  <XAxis
                    dataKey="period"
                    stroke="hsl(var(--muted-foreground))"
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="requested"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    name="Requested"
                  />
                  <Line
                    type="monotone"
                    dataKey="delivered"
                    stroke="hsl(var(--success))"
                    strokeWidth={2}
                    name="Delivered"
                  />
                  <Line
                    type="monotone"
                    dataKey="failed"
                    stroke="hsl(var(--destructive))"
                    strokeWidth={2}
                    name="Failed"
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
